/* ============================================================
   CMPU4003 Advanced Databases
   Campus Events Performance Dataset

   Generates:
       5,000 students
       1,000 events
       100,000 registrations

   Designed for:
       Supabase Free Plan
       Docker installations with approximately 4 GB RAM
   ============================================================ */

ALTER ROLE postgres
SET search_path TO campusevents, public;

BEGIN;

-- Allow additional time for the bulk insert without changing
-- the setting permanently for the database.
SET LOCAL statement_timeout = '5min';


-- ============================================================
-- 1. GENERATE 5,000 ADDITIONAL STUDENTS
--
-- Generated student IDs:
--     10001 to 15000
-- ============================================================

INSERT INTO student (
    student_id,
    name,
    email,
    programme
)
SELECT
    student_number + 10000 AS student_id,

    'Generated Student ' ||
        LPAD(student_number::text, 5, '0') AS name,

    'generated.student' ||
        LPAD(student_number::text, 5, '0') ||
        '@student.tudublin.ie' AS email,

    CASE
        -- Deliberately uneven distribution
        -- to support selectivity investigations.
        WHEN student_number % 20 < 9 THEN 'TU856'
        WHEN student_number % 20 < 15 THEN 'TU422'
        WHEN student_number % 20 < 18 THEN 'TU858'
        WHEN student_number % 20 < 19 THEN 'TU857'
        ELSE 'TU859'
    END AS programme

FROM generate_series(1, 5000) AS generated_students(student_number)

ON CONFLICT (student_id) DO NOTHING;



-- ============================================================
-- 2. GENERATE 1,000 ADDITIONAL EVENTS
--
-- Generated event IDs:
--     10001 to 11000
--
-- Event dates extend across approximately 1,000 days.
-- Venue and category distributions are deliberately uneven.
-- ============================================================

INSERT INTO event (
    event_id,
    title,
    event_date,
    venue_id,
    category_id,
    capacity
)
SELECT
    event_number + 10000 AS event_id,

    CASE ((event_number - 1) % 8)
        WHEN 0 THEN 'Technology Workshop '
        WHEN 1 THEN 'Careers Seminar '
        WHEN 2 THEN 'Academic Skills Event '
        WHEN 3 THEN 'Student Social Event '
        WHEN 4 THEN 'Wellbeing Workshop '
        WHEN 5 THEN 'Sports Activity '
        WHEN 6 THEN 'Industry Presentation '
        ELSE 'Campus Event '
    END ||
    LPAD(event_number::text, 4, '0') AS title,

    TIMESTAMP '2024-01-01 09:00:00'
        + ((event_number - 1) * INTERVAL '1 day')
        + ((event_number % 9) * INTERVAL '1 hour')
        AS event_date,

    CASE
        -- Some venues host considerably more events than others.
        WHEN event_number % 10 < 4 THEN 1
        WHEN event_number % 10 < 6 THEN 2
        WHEN event_number % 10 < 8 THEN 3
        WHEN event_number % 10 = 8 THEN 4
        ELSE 5
    END AS venue_id,

    CASE
        -- Technology and Careers are deliberately frequent.
        WHEN event_number % 20 < 7 THEN 2
        WHEN event_number % 20 < 12 THEN 1
        WHEN event_number % 20 < 15 THEN 3
        WHEN event_number % 20 < 17 THEN 4
        WHEN event_number % 20 < 19 THEN 5
        ELSE 6
    END AS category_id,

    CASE
        WHEN event_number % 5 = 0 THEN 300
        WHEN event_number % 5 = 1 THEN 200
        WHEN event_number % 5 = 2 THEN 150
        WHEN event_number % 5 = 3 THEN 120
        ELSE 100
    END AS capacity

FROM generate_series(1, 1000) AS generated_events(event_number)

ON CONFLICT (event_id) DO NOTHING;



-- ============================================================
-- 3. GENERATE 100,000 REGISTRATIONS
--
-- Each generated event receives 100 registrations.
--
-- Generated registration IDs:
--     1000001 to 1100000
--
-- Status distribution:
--     approximately 90% REGISTERED
--     approximately 7% CANCELLED
--     approximately 3% WAITLISTED
--
-- The student/event combinations are deterministic and unique.
-- ============================================================

INSERT INTO registration (
    registration_id,
    student_id,
    event_id,
    registered_at,
    status,
    attended
)
SELECT
    1000000
        + ((event_number - 1) * 100)
        + registration_number
        AS registration_id,

    10001
        + (
            (
                (event_number * 37)
                + (registration_number * 53)
            ) % 5000
        )
        AS student_id,

    10000 + event_number AS event_id,

    TIMESTAMP '2024-01-01 09:00:00'
        + ((event_number - 1) * INTERVAL '1 day')
        - (
            (1 + ((registration_number * 7) % 60))
            * INTERVAL '1 day'
        )
        + (
            (registration_number % 600)
            * INTERVAL '1 minute'
        )
        AS registered_at,

    CASE
        WHEN registration_number <= 90
            THEN 'REGISTERED'
        WHEN registration_number <= 97
            THEN 'CANCELLED'
        ELSE 'WAITLISTED'
    END AS status,

    CASE
        -- Only completed, non-cancelled registrations
        -- are recorded as attended.
        WHEN registration_number <= 90
             AND (
                 TIMESTAMP '2024-01-01 09:00:00'
                 + ((event_number - 1) * INTERVAL '1 day')
             ) < CURRENT_TIMESTAMP
             AND (
                 (event_number * 17 + registration_number * 13) % 10
             ) < 7
        THEN TRUE
        ELSE FALSE
    END AS attended

FROM
    generate_series(1, 1000)
        AS generated_events(event_number)

CROSS JOIN
    generate_series(1, 100)
        AS generated_registrations(registration_number)

ON CONFLICT (registration_id) DO NOTHING;


COMMIT;

